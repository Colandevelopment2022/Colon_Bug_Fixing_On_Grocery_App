    //
//  ResponseData.swift
//  APIData
//
//  Created by Dhana Gadupooti on 07/07/21.
//  Copyright © 2021 Sreelatha. All rights reserved.
//

// MARK: - ResponseData
struct ResponseData: Codable {
    let transaction: Transaction

    enum CodingKeys: String, CodingKey {
        case transaction = "Transaction"
    }
}

// MARK: - Transaction
struct Transaction: Codable {
    let responseCode, responseClass, responseDescription, responseClassDescription: String
//    let  approvalCode, account: String
//    let balance: Amount
//    let transactionID : String
//    let orderID: String
//    let amount, fees: Amount
//    let cardNumber: String
//    let payer: Payer
//    let cardToken, cardBrand, cardType, uniqueID: String

    enum CodingKeys: String, CodingKey {
        case responseCode = "ResponseCode"
        case responseClass = "ResponseClass"
        case responseDescription = "ResponseDescription"
        case responseClassDescription = "ResponseClassDescription"
//        case language = "Language"
//        case transactionID = "TransactionID"
//        case approvalCode = "ApprovalCode"
//        case account = "Account"
//        case balance = "Balance"
//        case orderID = "OrderID"
//        case amount = "Amount"
        
//        case fees = "Fees"
//        case cardNumber = "CardNumber"
//        case payer = "Payer"
//        case cardToken = "CardToken"
//        case cardBrand = "CardBrand"
//        case cardType = "CardType"
//        case uniqueID = "UniqueID"
    }
}

// MARK: - Amount
struct Amount: Codable {
    let value, printable: String

    enum CodingKeys: String, CodingKey {
        case value = "Value"
        case printable = "Printable"
    }
}

// MARK: - Payer
struct Payer: Codable {
    let information: String

    enum CodingKeys: String, CodingKey {
        case information = "Information"
    }
}
